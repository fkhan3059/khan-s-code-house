
<a href="https://www.bigdatauniversity.com"><img src="https://ibm.box.com/shared/static/cw2c7r3o20w9zn8gkecaeyjhgw3xdgbj.png" width="400" align="center"></a>

<h1 align="center"><font size="5">Classification with Python</font></h1>

In this notebook we try to practice all the classification algorithms that we learned in this course.

We load a dataset using Pandas library, and apply the following algorithms, and find the best one for this specific dataset by accuracy evaluation methods.

Lets first load required libraries:


```python
import itertools
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
import pandas as pd
import numpy as np
import matplotlib.ticker as ticker
from sklearn import preprocessing
%matplotlib inline
```

### About dataset

This dataset is about the performance of basketball teams. The __cbb.csv__ data set includes performance data about five seasons of 354 basketball teams. It includes following fields:

| Field          | Description                                                                           |
|----------------|---------------------------------------------------------------------------------------|
|TEAM |	The Division I college basketball school|
|CONF|	The Athletic Conference in which the school participates in (A10 = Atlantic 10, ACC = Atlantic Coast Conference, AE = America East, Amer = American, ASun = ASUN, B10 = Big Ten, B12 = Big 12, BE = Big East, BSky = Big Sky, BSth = Big South, BW = Big West, CAA = Colonial Athletic Association, CUSA = Conference USA, Horz = Horizon League, Ivy = Ivy League, MAAC = Metro Atlantic Athletic Conference, MAC = Mid-American Conference, MEAC = Mid-Eastern Athletic Conference, MVC = Missouri Valley Conference, MWC = Mountain West, NEC = Northeast Conference, OVC = Ohio Valley Conference, P12 = Pac-12, Pat = Patriot League, SB = Sun Belt, SC = Southern Conference, SEC = South Eastern Conference, Slnd = Southland Conference, Sum = Summit League, SWAC = Southwestern Athletic Conference, WAC = Western Athletic Conference, WCC = West Coast Conference)|
|G|	Number of games played|
|W|	Number of games won|
|ADJOE|	Adjusted Offensive Efficiency (An estimate of the offensive efficiency (points scored per 100 possessions) a team would have against the average Division I defense)|
|ADJDE|	Adjusted Defensive Efficiency (An estimate of the defensive efficiency (points allowed per 100 possessions) a team would have against the average Division I offense)|
|BARTHAG|	Power Rating (Chance of beating an average Division I team)|
|EFG_O|	Effective Field Goal Percentage Shot|
|EFG_D|	Effective Field Goal Percentage Allowed|
|TOR|	Turnover Percentage Allowed (Turnover Rate)|
|TORD|	Turnover Percentage Committed (Steal Rate)|
|ORB|	Offensive Rebound Percentage|
|DRB|	Defensive Rebound Percentage|
|FTR|	Free Throw Rate (How often the given team shoots Free Throws)|
|FTRD|	Free Throw Rate Allowed|
|2P_O|	Two-Point Shooting Percentage|
|2P_D|	Two-Point Shooting Percentage Allowed|
|3P_O|	Three-Point Shooting Percentage|
|3P_D|	Three-Point Shooting Percentage Allowed|
|ADJ_T|	Adjusted Tempo (An estimate of the tempo (possessions per 40 minutes) a team would have against the team that wants to play at an average Division I tempo)|
|WAB|	Wins Above Bubble (The bubble refers to the cut off between making the NCAA March Madness Tournament and not making it)|
|POSTSEASON|	Round where the given team was eliminated or where their season ended (R68 = First Four, R64 = Round of 64, R32 = Round of 32, S16 = Sweet Sixteen, E8 = Elite Eight, F4 = Final Four, 2ND = Runner-up, Champion = Winner of the NCAA March Madness Tournament for that given year)|
|SEED|	Seed in the NCAA March Madness Tournament|
|YEAR|	Season

### Load Data From CSV File  

Let's load the dataset [NB Need to provide link to csv file]


```python
df = pd.read_csv('https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/ML0120ENv3/Dataset/ML0101EN_EDX_skill_up/cbb.csv')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TEAM</th>
      <th>CONF</th>
      <th>G</th>
      <th>W</th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
      <th>TOR</th>
      <th>...</th>
      <th>FTRD</th>
      <th>2P_O</th>
      <th>2P_D</th>
      <th>3P_O</th>
      <th>3P_D</th>
      <th>ADJ_T</th>
      <th>WAB</th>
      <th>POSTSEASON</th>
      <th>SEED</th>
      <th>YEAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>North Carolina</td>
      <td>ACC</td>
      <td>40</td>
      <td>33</td>
      <td>123.3</td>
      <td>94.9</td>
      <td>0.9531</td>
      <td>52.6</td>
      <td>48.1</td>
      <td>15.4</td>
      <td>...</td>
      <td>30.4</td>
      <td>53.9</td>
      <td>44.6</td>
      <td>32.7</td>
      <td>36.2</td>
      <td>71.7</td>
      <td>8.6</td>
      <td>2ND</td>
      <td>1.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Villanova</td>
      <td>BE</td>
      <td>40</td>
      <td>35</td>
      <td>123.1</td>
      <td>90.9</td>
      <td>0.9703</td>
      <td>56.1</td>
      <td>46.7</td>
      <td>16.3</td>
      <td>...</td>
      <td>30.0</td>
      <td>57.4</td>
      <td>44.1</td>
      <td>36.2</td>
      <td>33.9</td>
      <td>66.7</td>
      <td>8.9</td>
      <td>Champions</td>
      <td>2.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Notre Dame</td>
      <td>ACC</td>
      <td>36</td>
      <td>24</td>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
      <td>15.3</td>
      <td>...</td>
      <td>26.0</td>
      <td>52.9</td>
      <td>46.5</td>
      <td>37.4</td>
      <td>36.9</td>
      <td>65.5</td>
      <td>2.3</td>
      <td>E8</td>
      <td>6.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Virginia</td>
      <td>ACC</td>
      <td>37</td>
      <td>29</td>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
      <td>15.1</td>
      <td>...</td>
      <td>33.4</td>
      <td>52.6</td>
      <td>46.3</td>
      <td>40.3</td>
      <td>34.7</td>
      <td>61.9</td>
      <td>8.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kansas</td>
      <td>B12</td>
      <td>37</td>
      <td>32</td>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
      <td>17.8</td>
      <td>...</td>
      <td>37.3</td>
      <td>52.7</td>
      <td>43.4</td>
      <td>41.3</td>
      <td>32.5</td>
      <td>70.1</td>
      <td>11.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
df.shape
```




    (1406, 24)



## Add Column
Next we'll add a column that will contain "true" if the wins above bubble are over 7 and "false" if not. We'll call this column Win Index or "windex" for short. 


```python
df['windex'] = np.where(df.WAB > 7, 'True', 'False')
```

# Data visualization and pre-processing



Next we'll filter the data set to the teams that made the Sweet Sixteen, the Elite Eight, and the Final Four in the post season. We'll also create a new dataframe that will hold the values with the new column.


```python
df1 = df[df['POSTSEASON'].str.contains('F4|S16|E8', na=False)]
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TEAM</th>
      <th>CONF</th>
      <th>G</th>
      <th>W</th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
      <th>TOR</th>
      <th>...</th>
      <th>2P_O</th>
      <th>2P_D</th>
      <th>3P_O</th>
      <th>3P_D</th>
      <th>ADJ_T</th>
      <th>WAB</th>
      <th>POSTSEASON</th>
      <th>SEED</th>
      <th>YEAR</th>
      <th>windex</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>Notre Dame</td>
      <td>ACC</td>
      <td>36</td>
      <td>24</td>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
      <td>15.3</td>
      <td>...</td>
      <td>52.9</td>
      <td>46.5</td>
      <td>37.4</td>
      <td>36.9</td>
      <td>65.5</td>
      <td>2.3</td>
      <td>E8</td>
      <td>6.0</td>
      <td>2016</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Virginia</td>
      <td>ACC</td>
      <td>37</td>
      <td>29</td>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
      <td>15.1</td>
      <td>...</td>
      <td>52.6</td>
      <td>46.3</td>
      <td>40.3</td>
      <td>34.7</td>
      <td>61.9</td>
      <td>8.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
      <td>True</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kansas</td>
      <td>B12</td>
      <td>37</td>
      <td>32</td>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
      <td>17.8</td>
      <td>...</td>
      <td>52.7</td>
      <td>43.4</td>
      <td>41.3</td>
      <td>32.5</td>
      <td>70.1</td>
      <td>11.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
      <td>True</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oregon</td>
      <td>P12</td>
      <td>37</td>
      <td>30</td>
      <td>118.4</td>
      <td>96.2</td>
      <td>0.9163</td>
      <td>52.3</td>
      <td>48.9</td>
      <td>16.1</td>
      <td>...</td>
      <td>52.6</td>
      <td>46.1</td>
      <td>34.4</td>
      <td>36.2</td>
      <td>69.0</td>
      <td>6.7</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
      <td>False</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Syracuse</td>
      <td>ACC</td>
      <td>37</td>
      <td>23</td>
      <td>111.9</td>
      <td>93.6</td>
      <td>0.8857</td>
      <td>50.0</td>
      <td>47.3</td>
      <td>18.1</td>
      <td>...</td>
      <td>47.2</td>
      <td>48.1</td>
      <td>36.0</td>
      <td>30.7</td>
      <td>65.5</td>
      <td>-0.3</td>
      <td>F4</td>
      <td>10.0</td>
      <td>2016</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 25 columns</p>
</div>




```python
df1['POSTSEASON'].value_counts()
```




    S16    32
    E8     16
    F4      8
    Name: POSTSEASON, dtype: int64



40 teams made it into the Sweet Sixteen, 20 into the Elite Eight, and 10 made it into the Final Four over 5 seasons. 


Lets plot some columns to underestand data better:


```python
# notice: installing seaborn might takes a few minutes
!conda install -c anaconda seaborn -y
```

    Solving environment: done
    
    ## Package Plan ##
    
      environment location: /opt/conda/envs/Python36
    
      added / updated specs: 
        - seaborn
    
    
    The following packages will be downloaded:
    
        package                    |            build
        ---------------------------|-----------------
        seaborn-0.10.0             |             py_0         161 KB  anaconda
        certifi-2020.4.5.1         |           py36_0         159 KB  anaconda
        openssl-1.1.1g             |       h7b6447c_0         3.8 MB  anaconda
        ca-certificates-2020.1.1   |                0         132 KB  anaconda
        ------------------------------------------------------------
                                               Total:         4.2 MB
    
    The following packages will be UPDATED:
    
        ca-certificates: 2020.1.1-0         --> 2020.1.1-0        anaconda
        certifi:         2020.4.5.1-py36_0  --> 2020.4.5.1-py36_0 anaconda
        openssl:         1.1.1g-h7b6447c_0  --> 1.1.1g-h7b6447c_0 anaconda
        seaborn:         0.9.0-pyh91ea838_1 --> 0.10.0-py_0       anaconda
    
    
    Downloading and Extracting Packages
    seaborn-0.10.0       | 161 KB    | ##################################### | 100% 
    certifi-2020.4.5.1   | 159 KB    | ##################################### | 100% 
    openssl-1.1.1g       | 3.8 MB    | ##################################### | 100% 
    ca-certificates-2020 | 132 KB    | ##################################### | 100% 
    Preparing transaction: done
    Verifying transaction: done
    Executing transaction: done



```python
import seaborn as sns

bins = np.linspace(df1.BARTHAG.min(), df1.BARTHAG.max(), 10)
g = sns.FacetGrid(df1, col="windex", hue="POSTSEASON", palette="Set1", col_wrap=6)
g.map(plt.hist, 'BARTHAG', bins=bins, ec="k")

g.axes[-1].legend()
plt.show()
```


![png](output_18_0.png)



```python
bins = np.linspace(df1.ADJOE.min(), df1.ADJOE.max(), 10)
g = sns.FacetGrid(df1, col="windex", hue="POSTSEASON", palette="Set1", col_wrap=2)
g.map(plt.hist, 'ADJOE', bins=bins, ec="k")

g.axes[-1].legend()
plt.show()
```


![png](output_19_0.png)


# Pre-processing:  Feature selection/extraction

### Lets look at how Adjusted Defense Efficiency plots


```python
bins = np.linspace(df1.ADJDE.min(), df1.ADJDE.max(), 10)
g = sns.FacetGrid(df1, col="windex", hue="POSTSEASON", palette="Set1", col_wrap=2)
g.map(plt.hist, 'ADJDE', bins=bins, ec="k")
g.axes[-1].legend()
plt.show()

```


![png](output_22_0.png)


We see that this data point doesn't impact the ability of a team to get into the Final Four. 

## Convert Categorical features to numerical values

Lets look at the postseason:


```python
df1.groupby(['windex'])['POSTSEASON'].value_counts(normalize=True)
```




    windex  POSTSEASON
    False   S16           0.605263
            E8            0.263158
            F4            0.131579
    True    S16           0.500000
            E8            0.333333
            F4            0.166667
    Name: POSTSEASON, dtype: float64



12% of teams with 6 or less wins above bubble make it into the final four while 18% of teams with 7 or more do.


Lets convert wins above bubble (winindex) under 7 to 0 and over 7 to 1:



```python
df['windex'].replace(to_replace=['False','True'], value=[0,1],inplace=True)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TEAM</th>
      <th>CONF</th>
      <th>G</th>
      <th>W</th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
      <th>TOR</th>
      <th>...</th>
      <th>2P_O</th>
      <th>2P_D</th>
      <th>3P_O</th>
      <th>3P_D</th>
      <th>ADJ_T</th>
      <th>WAB</th>
      <th>POSTSEASON</th>
      <th>SEED</th>
      <th>YEAR</th>
      <th>windex</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>North Carolina</td>
      <td>ACC</td>
      <td>40</td>
      <td>33</td>
      <td>123.3</td>
      <td>94.9</td>
      <td>0.9531</td>
      <td>52.6</td>
      <td>48.1</td>
      <td>15.4</td>
      <td>...</td>
      <td>53.9</td>
      <td>44.6</td>
      <td>32.7</td>
      <td>36.2</td>
      <td>71.7</td>
      <td>8.6</td>
      <td>2ND</td>
      <td>1.0</td>
      <td>2016</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Villanova</td>
      <td>BE</td>
      <td>40</td>
      <td>35</td>
      <td>123.1</td>
      <td>90.9</td>
      <td>0.9703</td>
      <td>56.1</td>
      <td>46.7</td>
      <td>16.3</td>
      <td>...</td>
      <td>57.4</td>
      <td>44.1</td>
      <td>36.2</td>
      <td>33.9</td>
      <td>66.7</td>
      <td>8.9</td>
      <td>Champions</td>
      <td>2.0</td>
      <td>2016</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Notre Dame</td>
      <td>ACC</td>
      <td>36</td>
      <td>24</td>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
      <td>15.3</td>
      <td>...</td>
      <td>52.9</td>
      <td>46.5</td>
      <td>37.4</td>
      <td>36.9</td>
      <td>65.5</td>
      <td>2.3</td>
      <td>E8</td>
      <td>6.0</td>
      <td>2016</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Virginia</td>
      <td>ACC</td>
      <td>37</td>
      <td>29</td>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
      <td>15.1</td>
      <td>...</td>
      <td>52.6</td>
      <td>46.3</td>
      <td>40.3</td>
      <td>34.7</td>
      <td>61.9</td>
      <td>8.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kansas</td>
      <td>B12</td>
      <td>37</td>
      <td>32</td>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
      <td>17.8</td>
      <td>...</td>
      <td>52.7</td>
      <td>43.4</td>
      <td>41.3</td>
      <td>32.5</td>
      <td>70.1</td>
      <td>11.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 25 columns</p>
</div>



## One Hot Encoding  
#### How about seed?


```python
df1.groupby(['SEED'])['POSTSEASON'].value_counts(normalize=True)
```




    SEED  POSTSEASON
    1.0   E8            0.750000
          F4            0.125000
          S16           0.125000
    2.0   S16           0.444444
          E8            0.333333
          F4            0.222222
    3.0   S16           0.700000
          E8            0.200000
          F4            0.100000
    4.0   S16           0.875000
          E8            0.125000
    5.0   S16           0.833333
          F4            0.166667
    6.0   E8            1.000000
    7.0   S16           0.800000
          F4            0.200000
    8.0   S16           1.000000
    9.0   E8            1.000000
    10.0  F4            1.000000
    11.0  S16           0.500000
          E8            0.250000
          F4            0.250000
    12.0  S16           1.000000
    Name: POSTSEASON, dtype: float64



#### Feature before One Hot Encoding


```python
df1[['ADJOE','ADJDE','BARTHAG','EFG_O','EFG_D']].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>118.4</td>
      <td>96.2</td>
      <td>0.9163</td>
      <td>52.3</td>
      <td>48.9</td>
    </tr>
    <tr>
      <th>6</th>
      <td>111.9</td>
      <td>93.6</td>
      <td>0.8857</td>
      <td>50.0</td>
      <td>47.3</td>
    </tr>
  </tbody>
</table>
</div>



#### Use one hot encoding technique to conver categorical varables to binary variables and append them to the feature Data Frame 


```python
Feature = df1[['ADJOE','ADJDE','BARTHAG','EFG_O','EFG_D']]
Feature = pd.concat([Feature,pd.get_dummies(df1['POSTSEASON'])], axis=1)
Feature.drop(['S16'], axis = 1,inplace=True)
Feature.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
      <th>E8</th>
      <th>F4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>118.4</td>
      <td>96.2</td>
      <td>0.9163</td>
      <td>52.3</td>
      <td>48.9</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>111.9</td>
      <td>93.6</td>
      <td>0.8857</td>
      <td>50.0</td>
      <td>47.3</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



### Feature selection

Lets defind feature sets, X:


```python
X = Feature
X[0:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
      <th>E8</th>
      <th>F4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>118.4</td>
      <td>96.2</td>
      <td>0.9163</td>
      <td>52.3</td>
      <td>48.9</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>111.9</td>
      <td>93.6</td>
      <td>0.8857</td>
      <td>50.0</td>
      <td>47.3</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



What are our lables? Round where the given team was eliminated or where their season ended (R68 = First Four, R64 = Round of 64, R32 = Round of 32, S16 = Sweet Sixteen, E8 = Elite Eight, F4 = Final Four, 2ND = Runner-up, Champion = Winner of the NCAA March Madness Tournament for that given year)|


```python
y = df1['POSTSEASON'].values
y[0:5]
```




    array(['E8', 'E8', 'E8', 'E8', 'F4'], dtype=object)



## Normalize Data 

Data Standardization give data zero mean and unit variance (technically should be done after train test split )


```python
X= preprocessing.StandardScaler().fit(X).transform(X)
X[0:5]
```

    /opt/conda/envs/Python36/lib/python3.6/site-packages/sklearn/preprocessing/data.py:645: DataConversionWarning: Data with input dtype uint8, float64 were all converted to float64 by StandardScaler.
      return self.partial_fit(X, y)
    /opt/conda/envs/Python36/lib/python3.6/site-packages/ipykernel/__main__.py:1: DataConversionWarning: Data with input dtype uint8, float64 were all converted to float64 by StandardScaler.
      if __name__ == '__main__':





    array([[ 0.28034482,  2.74329908, -2.45717765,  0.10027963,  0.94171924,
             1.58113883, -0.40824829],
           [ 0.64758014, -0.90102957,  1.127076  ,  0.39390887,  0.38123706,
             1.58113883, -0.40824829],
           [ 0.87710222, -1.0788017 ,  1.29403598,  0.72424177, -1.30020946,
             1.58113883, -0.40824829],
           [ 0.30329703,  0.63966222, -0.04972253, -0.52368251,  0.63600169,
             1.58113883, -0.40824829],
           [-1.18859646, -0.13068368, -0.87375079, -1.36786658, -0.17924511,
            -0.63245553,  2.44948974]])



## Training and Validation 

Split the data into Training and Validation data.


```python
# We split the X into train and test to find the best k
from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=4)
print ('Train set:', X_train.shape,  y_train.shape)
print ('Validation set:', X_val.shape,  y_val.shape)
```

    Train set: (44, 7) (44,)
    Validation set: (12, 7) (12,)


# Classification 

Now, it is your turn, use the training set to build an accurate model. Then use the validation set  to report the accuracy of the model
You should use the following algorithm:
- K Nearest Neighbor(KNN)
- Decision Tree
- Support Vector Machine
- Logistic Regression



# K Nearest Neighbor(KNN)

<b>Question  1 </b> Build a KNN model using a value of k equals three, find the accuracy on the validation data (X_val and y_val)

You can use <code> accuracy_score</cdoe>


```python
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
k= 3
kneigh= KNeighborsClassifier(n_neighbors= 3).fit(X_train, y_train)
kneigh
yhatk= kneigh.predict(X_val)
print('the accuracy of the model is:', accuracy_score(y_val, yhatk))
```

    the accuracy of the model is: 1.0


<b>Question  2</b> Determine the accuracy for the first 15 values of k the on the validation data:


```python
k= 15
mean_accuracy= np.zeros(k)
std_accuracy= np.zeros(k)
confusion_matrix= []

for n in range(1,k):
    neigh= KNeighborsClassifier(n_neighbors= n).fit(X_train, y_train)
    yhatk= neigh.predict(X_val)
    mean_accuracy[n]= accuracy_score(y_val, yhatk)
    std_accuracy[n]= np.std(yhatk== y_val)/ np.sqrt(yhatk.shape[0])
    
mean_accuracy[0:16]
```




    array([0.        , 1.        , 1.        , 1.        , 1.        ,
           1.        , 1.        , 0.91666667, 0.91666667, 0.83333333,
           0.83333333, 0.83333333, 0.83333333, 0.83333333, 0.83333333])



# Decision Tree

The following lines of code fit a <code>DecisionTreeClassifier</code>:


```python
from sklearn.tree import DecisionTreeClassifier
basketballtree= DecisionTreeClassifier(criterion= 'entropy', max_depth= 4)
basketballtree.fit(X_train, y_train)
predtree= basketballtree.predict(X_val)
print('the accuracy score is:', accuracy_score(y_val, predtree))
```

    the accuracy score is: 1.0


<b>Question  3</b> Determine the minumum   value for the parameter <code>max_depth</code> that improves results 


```python
from matplotlib import pyplot as plt
max_depth_test= np.linspace(1, 20, 20, endpoint=True)
accuracy_testdata= []
accuracy_traindata= []

for n in max_depth_test:
    basketballtree1= DecisionTreeClassifier(criterion= 'entropy', max_depth= n)
    basketballtree1.fit(X_train, y_train)
    
    predtree1= basketballtree1.predict(X_val)
    pred_train_data= basketballtree1.predict(X_train)
    
    
    accuracy_testdata.append(accuracy_score(y_val, predtree1))
    accuracy_traindata.append(accuracy_score(y_train, pred_train_data))

    
print(accuracy_testdata)
print(accuracy_traindata)


line1= plt.plot(max_depth_test, accuracy_testdata, 'b', label= 'test data points')
line2= plt.plot(max_depth_test, accuracy_traindata, 'r', label= 'train data points')
plt.xlabel('max depths')
plt.ylabel('accuracy score')
plt.show()

#minimum value of max_depth would be 2 that improves the results from the lower value
```

    [0.8333333333333334, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
    [0.8636363636363636, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]



![png](output_58_1.png)


# Support Vector Machine

<b>Question  4</b>Train the following linear  support  vector machine model and determine the accuracy on the validation data 


```python
from sklearn import svm
Var_svm= svm.SVC(kernel= 'linear')
Var_svm.fit(X_train, y_train)
vektor_predict= Var_svm.predict(X_val)
vektor_predict
```




    array(['F4', 'S16', 'S16', 'S16', 'S16', 'E8', 'S16', 'F4', 'S16', 'E8',
           'S16', 'S16'], dtype=object)




```python
from sklearn.metrics import jaccard_similarity_score
print('The accuracy score is:', jaccard_similarity_score(y_val, vektor_predict))
```

    The accuracy score is: 1.0


# Logistic Regression

<b>Question 5</b> Train a logistic regression model and determine the accuracy of the validation data (set C=0.01)


```python
from sklearn.linear_model import LogisticRegression
LR= LogisticRegression(C= 0.01, solver= 'liblinear')
LR.fit(X_train, y_train)
yhat_LR= LR.predict(X_val)
```

    /opt/conda/envs/Python36/lib/python3.6/site-packages/sklearn/linear_model/logistic.py:460: FutureWarning: Default multi_class will be changed to 'auto' in 0.22. Specify the multi_class option to silence this warning.
      "this warning.", FutureWarning)



```python
#calculating probability
yhat2_LR= LR.predict_proba(X_val)

from sklearn.metrics import jaccard_similarity_score
print('Accuracy of the model is:', jaccard_similarity_score(y_val, yhat_LR))

#OR
from sklearn.metrics import log_loss
print('The model probability accuracy is:', log_loss(y_val, yhat2_LR))
```

    Accuracy of the model is: 1.0
    The model probability accuracy is: 0.9795701978719524


# Model Evaluation using Test set


```python
from sklearn.metrics import f1_score
from sklearn.metrics import log_loss
```


```python
def jaccard_index(predictions, true):
    if (len(predictions) == len(true)):
        intersect = 0;
        for x,y in zip(predictions, true):
            if (x == y):
                intersect += 1
        return intersect / (len(predictions) + len(true) - intersect)
    else:
        return -1
```

<b>Question  5</b> Calculate the  F1 score and Jaccard Similarity score for each model from above. Use the Hyperparameter that performed best on the validation data.

### Load Test set for evaluation 


```python
test_df = pd.read_csv('https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/ML0120ENv3/Dataset/ML0101EN_EDX_skill_up/basketball_train.csv',error_bad_lines=False)
test_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TEAM</th>
      <th>CONF</th>
      <th>G</th>
      <th>W</th>
      <th>ADJOE</th>
      <th>ADJDE</th>
      <th>BARTHAG</th>
      <th>EFG_O</th>
      <th>EFG_D</th>
      <th>TOR</th>
      <th>...</th>
      <th>FTRD</th>
      <th>2P_O</th>
      <th>2P_D</th>
      <th>3P_O</th>
      <th>3P_D</th>
      <th>ADJ_T</th>
      <th>WAB</th>
      <th>POSTSEASON</th>
      <th>SEED</th>
      <th>YEAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>North Carolina</td>
      <td>ACC</td>
      <td>40</td>
      <td>33</td>
      <td>123.3</td>
      <td>94.9</td>
      <td>0.9531</td>
      <td>52.6</td>
      <td>48.1</td>
      <td>15.4</td>
      <td>...</td>
      <td>30.4</td>
      <td>53.9</td>
      <td>44.6</td>
      <td>32.7</td>
      <td>36.2</td>
      <td>71.7</td>
      <td>8.6</td>
      <td>2ND</td>
      <td>1.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Villanova</td>
      <td>BE</td>
      <td>40</td>
      <td>35</td>
      <td>123.1</td>
      <td>90.9</td>
      <td>0.9703</td>
      <td>56.1</td>
      <td>46.7</td>
      <td>16.3</td>
      <td>...</td>
      <td>30.0</td>
      <td>57.4</td>
      <td>44.1</td>
      <td>36.2</td>
      <td>33.9</td>
      <td>66.7</td>
      <td>8.9</td>
      <td>Champions</td>
      <td>2.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Notre Dame</td>
      <td>ACC</td>
      <td>36</td>
      <td>24</td>
      <td>118.3</td>
      <td>103.3</td>
      <td>0.8269</td>
      <td>54.0</td>
      <td>49.5</td>
      <td>15.3</td>
      <td>...</td>
      <td>26.0</td>
      <td>52.9</td>
      <td>46.5</td>
      <td>37.4</td>
      <td>36.9</td>
      <td>65.5</td>
      <td>2.3</td>
      <td>E8</td>
      <td>6.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Virginia</td>
      <td>ACC</td>
      <td>37</td>
      <td>29</td>
      <td>119.9</td>
      <td>91.0</td>
      <td>0.9600</td>
      <td>54.8</td>
      <td>48.4</td>
      <td>15.1</td>
      <td>...</td>
      <td>33.4</td>
      <td>52.6</td>
      <td>46.3</td>
      <td>40.3</td>
      <td>34.7</td>
      <td>61.9</td>
      <td>8.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kansas</td>
      <td>B12</td>
      <td>37</td>
      <td>32</td>
      <td>120.9</td>
      <td>90.4</td>
      <td>0.9662</td>
      <td>55.7</td>
      <td>45.1</td>
      <td>17.8</td>
      <td>...</td>
      <td>37.3</td>
      <td>52.7</td>
      <td>43.4</td>
      <td>41.3</td>
      <td>32.5</td>
      <td>70.1</td>
      <td>11.6</td>
      <td>E8</td>
      <td>1.0</td>
      <td>2016</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
test_df['windex'] = np.where(test_df.WAB > 7, 'True', 'False')
test_df1 = test_df[test_df['POSTSEASON'].str.contains('F4|S16|E8', na=False)]
test_df1. head()
test_df1.groupby(['windex'])['POSTSEASON'].value_counts(normalize=True)
test_Feature = test_df1[['ADJOE','ADJDE','BARTHAG','EFG_O','EFG_D']]
test_Feature = pd.concat([test_Feature,pd.get_dummies(test_df1['POSTSEASON'])], axis=1)
test_Feature.drop(['S16'], axis = 1,inplace=True)
test_Feature.head()
test_X=test_Feature
test_X= preprocessing.StandardScaler().fit(test_X).transform(test_X)
test_X[0:5]
```

    /opt/conda/envs/Python36/lib/python3.6/site-packages/sklearn/preprocessing/data.py:645: DataConversionWarning: Data with input dtype uint8, float64 were all converted to float64 by StandardScaler.
      return self.partial_fit(X, y)
    /opt/conda/envs/Python36/lib/python3.6/site-packages/ipykernel/__main__.py:10: DataConversionWarning: Data with input dtype uint8, float64 were all converted to float64 by StandardScaler.





    array([[ 3.37365934e-01,  2.66479976e+00, -2.46831661e+00,
             2.13703245e-01,  9.44090550e-01,  1.58113883e+00,
            -4.08248290e-01],
           [ 7.03145068e-01, -7.13778644e-01,  1.07370841e+00,
             4.82633172e-01,  4.77498943e-01,  1.58113883e+00,
            -4.08248290e-01],
           [ 9.31757027e-01, -8.78587347e-01,  1.23870131e+00,
             7.85179340e-01, -9.22275877e-01,  1.58113883e+00,
            -4.08248290e-01],
           [ 3.60227129e-01,  7.14563447e-01, -8.92254236e-02,
            -3.57772849e-01,  6.89586037e-01,  1.58113883e+00,
            -4.08248290e-01],
           [-1.12575060e+00,  3.92401673e-04, -9.03545224e-01,
            -1.13094639e+00,  1.09073363e-02, -6.32455532e-01,
             2.44948974e+00]])




```python
test_y = test_df1['POSTSEASON'].values
test_y[0:5]
```




    array(['E8', 'E8', 'E8', 'E8', 'F4'], dtype=object)



KNN


```python
KNN= KNeighborsClassifier(n_neighbors= 3).fit(X_train, y_train).predict(test_X)
print('The f1 score is:', f1_score(test_y, KNN, average= 'weighted'))
print('Jaccard similarity score for this model is:', jaccard_similarity_score(test_y, KNN))
```

    The f1 score is: 0.9561469320505465
    Jaccard similarity score for this model is: 0.9571428571428572


Decision Tree


```python
DT= DecisionTreeClassifier(criterion= 'entropy', max_depth= 2).fit(X_train, y_train).predict(test_X) #i changed the max_depth according to last analysis
print('The f1 score for decision tree is:', f1_score(test_y, DT, average= 'weighted'))
print('Jaccard similarity score for this model is:', jaccard_similarity_score(test_y, DT))
```

    The f1 score for decision tree is: 1.0
    Jaccard similarity score for this model is: 1.0


SVM


```python
SVM_model= svm.SVC(kernel= 'linear').fit(X_train, y_train).predict(test_X)
print('The f1 score for SVM is:', f1_score(y_val, vektor_predict, average= 'weighted'))
print('Jaccard similarity score for this model is:', jaccard_similarity_score(test_y, SVM_model))
```

    The f1 score for SVM is: 1.0
    Jaccard similarity score for this model is: 1.0


Logistic Regression


```python
LR_model= LR= LogisticRegression(C= 0.01, solver= 'liblinear').fit(X_train, y_train).predict(test_X)
print('The f1 score for logistic regression is:', f1_score(test_y, LR_model, average= 'weighted'))
print('Jaccard similarity score for this model for this model is:', jaccard_similarity_score(test_y, LR_model))
```

    The f1 score for logistic regression is: 1.0
    Jaccard similarity score for this model for this model is: 1.0


    /opt/conda/envs/Python36/lib/python3.6/site-packages/sklearn/linear_model/logistic.py:460: FutureWarning: Default multi_class will be changed to 'auto' in 0.22. Specify the multi_class option to silence this warning.
      "this warning.", FutureWarning)


# Report
You should be able to report the accuracy of the built model using different evaluation metrics:

| Algorithm          | Jaccard | F1-score | LogLoss |
|--------------------|---------|----------|---------|
| KNN                |.93      |.93       | NA      |
| Decision Tree      | 1       | 1        | NA      |
| SVM                | 1       | 1        | NA      |
| LogisticRegression | 1       | 1        | .97     |

<h2>Want to learn more?</h2>

IBM SPSS Modeler is a comprehensive analytics platform that has many machine learning algorithms. It has been designed to bring predictive intelligence to decisions made by individuals, by groups, by systems – by your enterprise as a whole. A free trial is available through this course, available here: <a href="http://cocl.us/ML0101EN-SPSSModeler">SPSS Modeler</a>

Also, you can use Watson Studio to run these notebooks faster with bigger datasets. Watson Studio is IBM's leading cloud solution for data scientists, built by data scientists. With Jupyter notebooks, RStudio, Apache Spark and popular libraries pre-packaged in the cloud, Watson Studio enables data scientists to collaborate on their projects without having to install anything. Join the fast-growing community of Watson Studio users today with a free account at <a href="https://cocl.us/ML0101EN_DSX">Watson Studio</a>

<h3>Thanks for completing this lesson!</h3>

<h4>Author:  <a href="https://ca.linkedin.com/in/saeedaghabozorgi">Saeed Aghabozorgi</a></h4>
<p><a href="https://ca.linkedin.com/in/saeedaghabozorgi">Saeed Aghabozorgi</a>, PhD is a Data Scientist in IBM with a track record of developing enterprise level applications that substantially increases clients’ ability to turn data into actionable knowledge. He is a researcher in data mining field and expert in developing advanced analytic methods like machine learning and statistical modelling on large datasets.</p>

<hr>

<p>Copyright &copy; 2018 <a href="https://cocl.us/DX0108EN_CC">Cognitive Class</a>. This notebook and its source code are released under the terms of the <a href="https://bigdatauniversity.com/mit-license/">MIT License</a>.</p>
